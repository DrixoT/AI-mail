import React, { useState, useEffect } from 'react';
import { Inbox, AlertTriangle, RefreshCw, Search, Settings, Briefcase, Users, Wallet, User, Package, MailCheck, LogOut } from 'lucide-react';
import { EmailList } from './components/EmailList';
import { SettingsModal } from './components/SettingsModal';
import { Welcome } from './pages/Welcome';
import { Chatbot } from './components/Chatbot';
import { fetchEmails } from './lib/gmail';
import { Email, EmailCategory } from './types';
import { supabase } from './lib/supabase';

function App() {
  const [session, setSession] = useState(null);
  const [emails, setEmails] = useState<Email[]>([]);
  const [view, setView] = useState<'inbox' | 'spam' | EmailCategory>('inbox');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('darkMode') === 'true';
    }
    return false;
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      localStorage.setItem('darkMode', isDarkMode.toString());
    }
  }, [isDarkMode]);

  useEffect(() => {
    const loadEmails = async () => {
      if (session?.provider_token) {
        const fetchedEmails = await fetchEmails(session.provider_token);
        setEmails(fetchedEmails);
      }
    };

    loadEmails();
  }, [session]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const handleDeleteEmail = (id: string) => {
    setEmails(emails.filter(email => email.id !== id));
  };

  const handleMarkAsRead = (id: string) => {
    setEmails(emails.map(email =>
      email.id === id ? { ...email, isRead: true } : email
    ));
  };

  const handleToggleSpam = (id: string) => {
    setEmails(emails.map(email => 
      email.id === id ? { ...email, isSpam: !email.isSpam } : email
    ));
  };

  const handleToggleStar = (id: string) => {
    setEmails(emails.map(email => 
      email.id === id ? { ...email, isStarred: !email.isStarred } : email
    ));
  };

  const handleCleanInbox = () => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    setEmails(emails.filter(email => {
      const emailDate = new Date(email.date);
      return !email.isSpam && (!email.isRead || emailDate > thirtyDaysAgo);
    }));
  };

  if (!session) {
    return <Welcome onLogin={() => {}} />;
  }

  const filteredEmails = emails
    .filter(email => {
      if (view === 'inbox') return !email.isSpam;
      if (view === 'spam') return email.isSpam;
      return email.category === view && !email.isSpam;
    })
    .filter(email => 
      email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      email.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      email.sender.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const unreadCount = emails.filter(email => !email.isRead && !email.isSpam).length;
  const spamCount = emails.filter(email => email.isSpam).length;

  const categories: { id: EmailCategory; icon: React.ReactNode; label: string }[] = [
    { id: 'Business', icon: <Briefcase className="w-4 h-4" />, label: 'Business' },
    { id: 'Social', icon: <Users className="w-4 h-4" />, label: 'Social' },
    { id: 'Finance', icon: <Wallet className="w-4 h-4" />, label: 'Finance' },
    { id: 'Personal', icon: <User className="w-4 h-4" />, label: 'Personal' },
    { id: 'Miscellaneous', icon: <Package className="w-4 h-4" />, label: 'Other' },
  ];

  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?w=1600')] bg-cover bg-fixed bg-center before:content-[''] before:absolute before:inset-0 before:bg-purple-900/30 before:backdrop-blur-sm relative">
      <div className="relative max-w-6xl mx-auto p-8">
        <div className="bg-white/80 dark:bg-slate-900/90 rounded-2xl shadow-lg border border-white/20 dark:border-slate-800/50 overflow-hidden backdrop-blur-xl">
          {/* Header */}
          <div className="bg-gradient-to-br from-purple-600 to-indigo-700 dark:from-purple-600/90 dark:to-indigo-800/90 p-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                  <MailCheck className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl text-white app-title">
                    Manage Pro
                  </h1>
                  <p className="app-subtitle mt-0.5">
                    Your Email Buddy
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleCleanInbox}
                  className="flex items-center space-x-2 bg-white/10 hover:bg-white/15 text-white/90 px-4 py-2.5 rounded-lg transition-all duration-200 text-sm font-medium backdrop-blur-sm"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Clean Inbox</span>
                </button>
                <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="p-2.5 hover:bg-white/10 rounded-lg transition-all duration-200"
                >
                  <Settings className="w-5 h-5 text-white/80" />
                </button>
                <button 
                  onClick={handleSignOut}
                  className="p-2.5 hover:bg-white/10 rounded-lg transition-all duration-200"
                >
                  <LogOut className="w-5 h-5 text-white/80" />
                </button>
              </div>
            </div>

            {/* Search Bar */}
            <div className="mt-8">
              <div className="relative max-w-2xl mx-auto">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/50 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search emails..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 rounded-lg bg-white/10 border border-white/10 focus:outline-none focus:ring-2 focus:ring-white/20 focus:border-transparent transition-all duration-200 text-white placeholder-white/50 text-sm backdrop-blur-sm"
                />
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="p-6">
            <div className="flex items-center space-x-2 mb-6">
              <button
                onClick={() => setView('inbox')}
                className={`nav-button ${view === 'inbox' ? 'nav-button-active' : 'nav-button-inactive'}`}
              >
                <Inbox className="w-4 h-4" />
                <span>Inbox</span>
                {unreadCount > 0 && (
                  <span className="ml-1.5 bg-purple-600 text-white text-xs px-2 py-0.5 rounded-full">
                    {unreadCount}
                  </span>
                )}
              </button>
              {categories.map(category => (
                <button
                  key={category.id}
                  onClick={() => setView(category.id)}
                  className={`nav-button ${view === category.id ? 'nav-button-active' : 'nav-button-inactive'}`}
                >
                  {category.icon}
                  <span>{category.label}</span>
                </button>
              ))}
              <button
                onClick={() => setView('spam')}
                className={`nav-button ${view === 'spam' ? 'nav-button-active' : 'nav-button-inactive'}`}
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Spam</span>
                {spamCount > 0 && (
                  <span className="ml-1.5 bg-red-500/90 text-white text-xs px-2 py-0.5 rounded-full">
                    {spamCount}
                  </span>
                )}
              </button>
            </div>

            {filteredEmails.length === 0 ? (
              <div className="text-center py-16 bg-white/50 dark:bg-slate-800/50 rounded-xl border border-white/10 dark:border-slate-700/50">
                <div className="text-slate-400 dark:text-slate-600 text-5xl mb-4">
                  {searchQuery ? '🔍' : '📭'}
                </div>
                <h3 className="text-xl font-medium text-slate-700 dark:text-slate-200">
                  {searchQuery ? 'No matching emails found' : `No emails in ${view}`}
                </h3>
                <p className="text-slate-500 dark:text-slate-400 mt-2 text-sm">
                  {searchQuery ? 'Try different search terms' : 'Your inbox is empty'}
                </p>
              </div>
            ) : (
              <EmailList
                emails={filteredEmails}
                onDeleteEmail={handleDeleteEmail}
                onToggleSpam={handleToggleSpam}
                onMarkAsRead={handleMarkAsRead}
                onToggleStar={handleToggleStar}
              />
            )}
          </div>
        </div>
      </div>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        accounts={[]}
        onConnectAccount={() => {}}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
      />

      <Chatbot />
    </div>
  );
}

export default App;