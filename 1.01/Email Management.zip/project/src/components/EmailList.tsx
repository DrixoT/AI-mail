import React from 'react';
import { Mail, Trash2, AlertCircle, Star, Briefcase, Users, Wallet, User, Package } from 'lucide-react';
import { Email, EmailCategory } from '../types';
import clsx from 'clsx';

interface EmailListProps {
  emails: Email[];
  onDeleteEmail: (id: string) => void;
  onToggleSpam: (id: string) => void;
  onMarkAsRead: (id: string) => void;
  onToggleStar: (id: string) => void;
}

const categoryConfig: Record<EmailCategory, { icon: React.ReactNode; color: string }> = {
  Business: { icon: <Briefcase className="w-3 h-3" />, color: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300' },
  Social: { icon: <Users className="w-3 h-3" />, color: 'bg-purple-100 text-purple-700 dark:bg-purple-500/20 dark:text-purple-300' },
  Finance: { icon: <Wallet className="w-3 h-3" />, color: 'bg-green-100 text-green-700 dark:bg-green-500/20 dark:text-green-300' },
  Personal: { icon: <User className="w-3 h-3" />, color: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300' },
  Miscellaneous: { icon: <Package className="w-3 h-3" />, color: 'bg-slate-100 text-slate-700 dark:bg-slate-500/20 dark:text-slate-300' }
};

export const EmailList: React.FC<EmailListProps> = ({ 
  emails, 
  onDeleteEmail, 
  onToggleSpam,
  onMarkAsRead,
  onToggleStar
}) => {
  return (
    <div className="space-y-3">
      {emails.map((email) => (
        <div
          key={email.id}
          className={clsx(
            "email-card p-5 rounded-lg border",
            email.isSpam 
              ? "bg-red-50/50 border-red-100 hover:border-red-200 dark:bg-red-500/5 dark:border-red-500/10 dark:hover:border-red-500/20" 
              : "bg-white/80 border-white/20 hover:border-white/30 dark:bg-slate-800/50 dark:border-slate-700/50 dark:hover:border-slate-600/50",
            !email.isRead && "ring-1 ring-purple-100 dark:ring-purple-500/20"
          )}
          onClick={() => onMarkAsRead(email.id)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3.5">
              <div className={clsx(
                "w-10 h-10 rounded-lg flex items-center justify-center",
                email.isRead ? "bg-slate-100/80 dark:bg-slate-700/50" : "bg-purple-600 dark:bg-purple-500"
              )}>
                <Mail className={clsx(
                  "w-5 h-5",
                  email.isRead ? "text-slate-500 dark:text-slate-400" : "text-white"
                )} />
              </div>
              <div>
                <span className="text-sm font-medium text-slate-800 dark:text-slate-200">{email.sender}</span>
                <span className="text-xs text-slate-500 dark:text-slate-400 block mt-0.5">
                  {new Date(email.date).toLocaleDateString(undefined, { 
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleSpam(email.id);
                }}
                className={clsx(
                  "p-2 rounded-lg transition-colors",
                  email.isSpam 
                    ? "text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-500/10" 
                    : "text-slate-400 hover:bg-slate-50 hover:text-slate-600 dark:hover:bg-slate-700/50 dark:hover:text-slate-300"
                )}
                title={email.isSpam ? "Mark as not spam" : "Mark as spam"}
              >
                <AlertCircle className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteEmail(email.id);
                }}
                className="p-2 rounded-lg text-slate-400 hover:bg-slate-50 hover:text-slate-600 dark:hover:bg-slate-700/50 dark:hover:text-slate-300 transition-colors"
                title="Delete email"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-medium text-slate-900 dark:text-white">{email.subject}</h3>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleStar(email.id);
                }}
                className={clsx(
                  "p-1.5 rounded-lg transition-all duration-300 transform hover:scale-110",
                  email.isStarred 
                    ? "text-amber-400 hover:text-amber-500 animate-star" 
                    : "text-slate-300 hover:text-amber-400 dark:text-slate-600 dark:hover:text-amber-400"
                )}
              >
                <Star 
                  className={clsx(
                    "w-5 h-5 transition-transform duration-300",
                    email.isStarred && "fill-current"
                  )} 
                />
              </button>
            </div>
            <p className="text-slate-600 dark:text-slate-300 mt-1.5 text-sm line-clamp-2">{email.content}</p>
          </div>
          <div className="flex items-center justify-end mt-3 space-x-2">
            <span className={`text-xs px-2.5 py-1 rounded-full font-medium flex items-center space-x-1 ${categoryConfig[email.category].color}`}>
              {categoryConfig[email.category].icon}
              <span>{email.category}</span>
            </span>
            {!email.isRead && (
              <span className="text-xs bg-purple-100 text-purple-700 dark:bg-purple-500/20 dark:text-purple-300 px-2.5 py-1 rounded-full font-medium">
                Unread
              </span>
            )}
            {email.isSpam && (
              <span className="text-xs bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300 px-2.5 py-1 rounded-full font-medium">
                Spam
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};