import React, { useState } from 'react';
import { X, Mail, AlertCircle, Sun, Moon, Loader2, Check, AlertTriangle } from 'lucide-react';
import { EmailAccount } from '../types';
import { supabase } from '../lib/supabase';
import { z } from 'zod';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: EmailAccount[];
  onConnectAccount: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

const emailSchema = z.string().email("Please enter a valid email address");

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  accounts,
  isDarkMode,
  onToggleTheme,
}) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleGoogleConnect = async () => {
    try {
      setIsConnecting(true);
      setError(null);
      
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          scopes: 'email https://www.googleapis.com/auth/gmail.readonly',
          queryParams: {
            access_type: 'offline',
            prompt: 'consent'
          }
        }
      });

      if (error) throw error;
      
      setSuccess('Successfully connected Google account!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to connect account');
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnectAccount = async (accountId: string) => {
    try {
      setError(null);
      const { error } = await supabase
        .from('email_accounts')
        .delete()
        .eq('id', accountId);

      if (error) throw error;
      setSuccess('Account disconnected successfully');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to disconnect account');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl shadow-xl">
        <div className="flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          </button>
        </div>
        
        <div className="p-6 space-y-8">
          {/* Theme Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {isDarkMode ? (
                <Moon className="w-5 h-5 text-slate-400" />
              ) : (
                <Sun className="w-5 h-5 text-amber-500" />
              )}
              <span className="font-medium text-slate-900 dark:text-white">
                Dark Mode
              </span>
            </div>
            <button
              role="switch"
              aria-checked={isDarkMode}
              onClick={onToggleTheme}
              className="toggle-switch"
            >
              <span className="toggle-switch-thumb" />
            </button>
          </div>

          {/* Connected Accounts */}
          <div>
            <h3 className="text-sm font-medium text-slate-900 dark:text-white mb-4">Connected Accounts</h3>
            <div className="space-y-3">
              {accounts.map(account => (
                <div
                  key={account.id}
                  className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700/50"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-white dark:bg-slate-700 rounded-lg flex items-center justify-center border border-slate-200 dark:border-slate-600">
                      <Mail className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                    </div>
                    <div>
                      <div className="font-medium text-slate-900 dark:text-white">{account.name}</div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">{account.email}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                      account.isConnected 
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                    }`}>
                      {account.isConnected ? 'Connected' : 'Disconnected'}
                    </span>
                    <button
                      onClick={() => handleDisconnectAccount(account.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors dark:hover:bg-red-500/10"
                    >
                      Disconnect
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Status Messages */}
          {error && (
            <div className="bg-red-50 dark:bg-red-500/5 p-4 rounded-lg flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-red-900 dark:text-red-300">Error</h4>
                <p className="text-sm text-red-700/90 dark:text-red-300/90 mt-1">{error}</p>
              </div>
            </div>
          )}

          {success && (
            <div className="bg-green-50 dark:bg-green-500/5 p-4 rounded-lg flex items-start space-x-3">
              <Check className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-green-900 dark:text-green-300">Success</h4>
                <p className="text-sm text-green-700/90 dark:text-green-300/90 mt-1">{success}</p>
              </div>
            </div>
          )}

          {/* Connect Account Button */}
          <div>
            <button
              onClick={handleGoogleConnect}
              disabled={isConnecting}
              className="w-full py-3 px-4 bg-gradient-to-br from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white rounded-lg font-medium transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isConnecting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Mail className="w-4 h-4" />
              )}
              <span>{isConnecting ? 'Connecting...' : 'Connect Email Account'}</span>
            </button>
          </div>

          <div className="bg-indigo-50/50 dark:bg-indigo-500/5 p-4 rounded-lg flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-indigo-900 dark:text-indigo-300">Email Sync</h4>
              <p className="text-sm text-indigo-700/90 dark:text-indigo-300/90 mt-1">
                Connected accounts will automatically sync every 5 minutes. You can manually refresh your inbox using the refresh button.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};