import { Email, EmailAccount } from './types';

export const sampleAccounts: EmailAccount[] = [
  {
    id: '1',
    type: 'gmail',
    email: 'john.doe@gmail.com',
    name: 'John Doe',
    isConnected: true
  }
];

export const sampleEmails: Email[] = [
  {
    id: '1',
    subject: 'Q1 2024 Financial Report Review',
    sender: 'finance.director@company.com',
    content: 'Please review the attached Q1 financial reports before our board meeting next week. Key highlights include a 23% revenue growth and successful cost optimization initiatives across all departments.',
    date: '2024-03-15T09:30:00',
    isSpam: false,
    isRead: false,
    category: 'Business'
  },
  {
    id: '2',
    subject: 'URGENT: Your Account Will Be SUSPENDED!',
    sender: 'security-alert@suspicious-bank.net',
    content: 'Your account has been flagged for suspicious activity! Click here immediately to verify your identity and prevent account suspension. You must act within 24 hours!',
    date: '2024-03-15T10:15:00',
    isSpam: true,
    isRead: false,
    category: 'Finance'
  },
  {
    id: '3',
    subject: 'Team Building Event - Next Friday',
    sender: 'hr@company.com',
    content: 'Join us for our monthly team building event next Friday at 3 PM. We\'ll be having a virtual cooking class followed by team games. Please RSVP by Wednesday and let us know about any dietary restrictions.',
    date: '2024-03-14T14:20:00',
    isSpam: false,
    isRead: true,
    category: 'Social'
  },
  {
    id: '4',
    subject: 'Family Reunion Planning',
    sender: 'mom@family.com',
    content: 'Hi sweetie, we need to start planning the summer family reunion. I was thinking we could host it at the lake house this year. What do you think?',
    date: '2024-03-14T16:45:00',
    isSpam: false,
    isRead: false,
    category: 'Personal'
  },
  {
    id: '5',
    subject: 'Project Phoenix - Development Update',
    sender: 'tech.lead@company.com',
    content: 'Here\'s the latest update on Project Phoenix: Backend API is 90% complete, front-end implementation is on track, and we\'ve successfully integrated the new authentication system. Please review the attached technical documentation.',
    date: '2024-03-13T11:30:00',
    isSpam: false,
    isRead: false,
    category: 'Business'
  }
];