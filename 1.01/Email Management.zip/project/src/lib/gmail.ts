import { supabase } from './supabase';
import { Email } from '../types';

export const fetchEmails = async (accessToken: string): Promise<Email[]> => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fetch-emails`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ accessToken }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to fetch emails');
    }

    const emails = await response.json();
    return emails;
  } catch (error) {
    console.error('Error fetching emails:', error);
    return [];
  }
};