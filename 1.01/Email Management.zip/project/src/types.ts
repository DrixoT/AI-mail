export type EmailCategory = 'Business' | 'Social' | 'Finance' | 'Personal' | 'Miscellaneous';

export interface Email {
  id: string;
  subject: string;
  sender: string;
  content: string;
  date: string;
  isSpam: boolean;
  isRead: boolean;
  isStarred?: boolean;
  category: EmailCategory;
}

export interface EmailAccount {
  id: string;
  type: 'gmail' | 'outlook' | 'other';
  email: string;
  name: string;
  isConnected: boolean;
}