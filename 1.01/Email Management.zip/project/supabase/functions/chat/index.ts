import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message } = await req.json();

    // Simple response system for testing
    const responses = {
      "help": "I can help you manage your emails, categorize them, and clean up your inbox. What would you like to do?",
      "clean": "To clean your inbox, I can help you identify and remove spam, organize emails into categories, and archive old messages.",
      "categories": "Your emails are automatically categorized into: Business, Social, Finance, Personal, and Miscellaneous.",
      "spam": "I can help you identify potential spam emails and move them to the spam folder. Would you like me to do that?",
    };

    let response = "I understand you said: " + message + ". How can I help you with that?";

    // Check if message contains any keywords
    for (const [key, value] of Object.entries(responses)) {
      if (message.toLowerCase().includes(key)) {
        response = value;
        break;
      }
    }

    return new Response(
      JSON.stringify({ response }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});