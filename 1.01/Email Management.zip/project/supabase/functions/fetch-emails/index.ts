import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { google } from "npm:googleapis@129.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { accessToken } = await req.json();
    
    if (!accessToken) {
      return new Response(
        JSON.stringify({ error: "Access token is required" }),
        { 
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }

    const auth = new google.auth.OAuth2();
    auth.setCredentials({ access_token: accessToken });

    const gmail = google.gmail({ version: "v1", auth });
    
    const response = await gmail.users.messages.list({
      userId: "me",
      maxResults: 50,
    });

    const emails = [];
    
    if (response.data.messages) {
      for (const message of response.data.messages) {
        const email = await gmail.users.messages.get({
          userId: "me",
          id: message.id,
        });

        const headers = email.data.payload?.headers;
        const subject = headers?.find(h => h.name === "Subject")?.value || "No Subject";
        const from = headers?.find(h => h.name === "From")?.value || "Unknown Sender";
        const date = headers?.find(h => h.name === "Date")?.value || new Date().toISOString();
        
        let content = "";
        if (email.data.payload?.parts?.[0]?.body?.data) {
          content = atob(email.data.payload.parts[0].body.data.replace(/-/g, "+").replace(/_/g, "/"));
        } else if (email.data.payload?.body?.data) {
          content = atob(email.data.payload.body.data.replace(/-/g, "+").replace(/_/g, "/"));
        }

        const category = categorizeEmail(subject, content);

        emails.push({
          id: message.id,
          subject,
          sender: from,
          content,
          date,
          isSpam: email.data.labelIds?.includes("SPAM") || false,
          isRead: !email.data.labelIds?.includes("UNREAD"),
          category,
        });
      }
    }

    return new Response(
      JSON.stringify(emails),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});

function categorizeEmail(subject: string, content: string): string {
  const lowerSubject = subject.toLowerCase();
  const lowerContent = content.toLowerCase();

  if (lowerSubject.includes("invoice") || lowerContent.includes("payment")) {
    return "Finance";
  }
  if (lowerSubject.includes("meeting") || lowerContent.includes("project")) {
    return "Business";
  }
  if (lowerSubject.includes("facebook") || lowerContent.includes("social")) {
    return "Social";
  }
  if (lowerSubject.includes("family") || lowerContent.includes("personal")) {
    return "Personal";
  }
  return "Miscellaneous";
}